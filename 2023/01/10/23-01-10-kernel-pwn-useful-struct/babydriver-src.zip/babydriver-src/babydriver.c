#include<linux/init.h>
#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/fs.h>
#include<asm/uaccess.h>
#include<linux/io.h>
#include<linux/cdev.h>
#include<linux/slab.h>
#include<linux/device.h>


MODULE_LICENSE("Dual BSD/GPL");

static int test_major = 0;
static int test_minor = 0;

static struct cdev cdev_0;
dev_t babydev_no;
struct class *babydev_class;

struct babydevice{
	char* device_buf;
	uint64_t device_buf_len;
};

struct babydevice babydev_struct;


int babyrelease(struct inode *inode, struct file *filp)
{
	kfree(babydev_struct.device_buf);
	printk("device release\n");
	return 0;
}

int babyopen(struct inode *inode, struct file *filp)
{
	babydev_struct.device_buf = kmalloc(64,0x24000C0);
	babydev_struct.device_buf_len = 64;
	printk("device open\n");
	return 0;
}


static ssize_t babyread(struct file *file, char *buf, size_t count, loff_t *ppos)
{
	ssize_t v6; 

	if ( !babydev_struct.device_buf )
	  return -1;
	if ( babydev_struct.device_buf_len > count )
	{
	  v6 = count;
	  copy_to_user(buf,babydev_struct.device_buf,v6);
	  return v6;
	}
	return -2;
}


static ssize_t babywrite(struct file *file, const char *buf, size_t count, loff_t *ppos)
{
	if ( !babydev_struct.device_buf )
		return -1;

	if ( babydev_struct.device_buf_len > count )
	{
		copy_from_user(babydev_struct.device_buf,buf,count);
		return count;
	}else{
		size_t offset = count - babydev_struct.device_buf_len;
		size_t len = babydev_struct.device_buf_len - offset;
		if( offset < babydev_struct.device_buf_len){
			printk("[+] offset: %lx\n",offset);
			printk("[+] len: %lx\n",len);
			copy_from_user((uint64_t)((char*)babydev_struct.device_buf+offset),buf,len);
		}else{
			return -3;
		}
	}

	return -2;
}


long babyioctl(struct file *fd, unsigned int cmd, unsigned long arg)
{
	size_t v4;	

	v4 = arg;
	if ( cmd == 65537 )
	{
	  kfree(babydev_struct.device_buf);
	  babydev_struct.device_buf = kmalloc(v4,0x24000C0);
	  babydev_struct.device_buf_len = v4;
	  printk("alloc done\n");
	  return 0LL;
	}
	else
	{
	  printk("defalut:arg is %ld",arg);
	  return -22;
	}
}

struct file_operations baby_fops = {
	.owner = THIS_MODULE,
	.write = babywrite,
	.read = babyread,
	.unlocked_ioctl = babyioctl,
	.open = babyopen,
	.release = babyrelease,
};

static int babydriver_init(void) 
{
	int v0; 
	int v1; 
	struct device *v2; 

	if( alloc_chrdev_region(&babydev_no, 0, 1, "babydev") >= 0 ){		// 申请一个主设备号
		cdev_init(&cdev_0, &baby_fops);									// 初始化字符设备cdev结构体，并建立其与操作方法集的关系
		cdev_0.owner = THIS_MODULE;
		test_major = MAJOR(babydev_no);
		test_minor = MINOR(babydev_no);
		printk("[+] test_major: %d ; test_minor: %d \n",test_major,test_minor);
		v1 = cdev_add(&cdev_0, babydev_no, 1);							// 将字符设备添加到系统中
		if ( v1 >= 0 ){
			babydev_class = class_create(THIS_MODULE, "babydev_class");			// 创建一个class结构体
			if ( babydev_class ){
				v2 = device_create(babydev_class, 0, MKDEV(test_major,0), 0, "babydev");		// 自动创建设备节点
				if ( v2 ) return 0;
				printk("create device failed");
				class_destroy(babydev_class);
			}else{
				printk("create class failed");
			}
			cdev_del(&cdev_0);
		} else{
			printk("cdev init failed");
		}
		unregister_chrdev_region(babydev_no, 1);
		return v1;
	}
	printk("alloc_chrdev_region failed");
	return 1;
}

static void babydriver_exit(void) 
{
  device_destroy(babydev_class, babydev_no);		// 删除设备
  class_destroy(babydev_class);						// 删除类
  cdev_del(&cdev_0);								// 删除字符设备
  unregister_chrdev_region(babydev_no, 1);			// 注销设备号
}

module_init(babydriver_init);
module_exit(babydriver_exit);
