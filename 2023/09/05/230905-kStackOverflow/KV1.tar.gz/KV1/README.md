# AVSS 2023 Qualifier - kStackOverflow (KV1)

`kStackOverflow` is the first set of challenges in the AVSS kernel challenges. You need to exploit a stack overflow vulnerability in the kernel to retrieve the `/system/flag` file.



## Vulnerability Info

**Vulnerabilities limitation**

> In this challenge, you are only allowed to exploit the following vulnerabilities.

The stack buffer overflow vulnerability present in the functions `stackof_write` and `stackof_read` due to a lack of length validation. See the patch for more details.

```c
+noinline long stackof_read(char __user * addr, unsigned long len) {
+    char buffer[0x100];
+    long ans;
+    memset(buffer, 0, sizeof(buffer));
+    ans=my_ctu(buffer,addr,len);
+    return ans;
+}
+
+noinline long sys_stackof_handler(char __user * addr, unsigned long len, int option) {    
+    if(option){
+	    return stackof_read(addr,len);
+    }
+    else{
+	    return stackof_write(addr,len);
+    }
+}
```



## Source Code

### Android 7
```
# AOSP
repo init -u https://android.googlesource.com/platform/manifest -b android-7.1.1_r20
# Kernel
git clone https://android.googlesource.com/kernel/goldfish.git
git checkout android-goldfish-3.10
```

### Android 8
```
# AOSP
repo init -u https://android.googlesource.com/platform/manifest -b android-8.1.0_r27
# Kernel
git clone https://android.googlesource.com/kernel/goldfish.git
git checkout android-goldfish-3.18
```

### Android 9
```
# AOSP
repo init -u https://android.googlesource.com/platform/manifest -b android-9.0.0_r61
# Kernel
git clone https://android.googlesource.com/kernel/goldfish.git
git checkout android-goldfish-3.18
```
### Android 10
```
# AOSP
repo init -u https://android.googlesource.com/platform/manifest -b android-10.0.0_r8
# Kernel
repo init -u https://android.googlesource.com/kernel/manifest -b q-goldfish-android-goldfish-4.14-dev
```
### Android 11
```
# AOSP
repo init -u https://android.googlesource.com/platform/manifest -b android-11.0.0_r34
# Kernel
repo init -u https://android.googlesource.com/kernel/manifest -b common-android11-5.4
```
### Android 12
```
# AOSP
repo init -u https://android.googlesource.com/platform/manifest -b android12-gsi
# Kernel
repo init -u https://android.googlesource.com/kernel/manifest -b common-android12-5.10
```
### Android 13
```
# AOSP
repo init -u https://android.googlesource.com/platform/manifest -b android13-gsi
# Kernel
repo init -u https://android.googlesource.com/kernel/manifest -b common-android13-5.15
```



### Apply Patch

```
/bin/bash patcher.sh patch PROJECT_ROOT PATCHFILE
```

Next, you can follow the official website's [instructions](https://source.android.com/docs/setup/build/building) to proceed with the AOSP and kernel build process.



## Local Environment

Since the environment files are stored on cloud object storage service, you can obtain this series of challenges by running the following command.

```
# Android 7
python3 ./envfetcher.py KV1A7
# Android 8
python3 ./envfetcher.py KV1A8
# Android 9
python3 ./envfetcher.py KV1A9
# Android 10
python3 ./envfetcher.py KV1A10
# Android 11
python3 ./envfetcher.py KV1A11
# Android 12
python3 ./envfetcher.py KV1A12
# Android 13
python3 ./envfetcher.py KV1A13
```



## Remote Connection

In kernel challenge `kStackOverflow`, you can connect to the adb shell in emulator, upload and execute your exploit.



## Notes

1. **Vulnerability Limitation**: Contestants must only exploit the vulnerabilities in `Vulnerability Info` Provided.
2. After starting the remote environment, it may take several minutes for the emulator to start.
3. For challenges with a host of x86-64, you will need to upload your exploit to the remote environment using methods like `base64`. However, for challenges with a host of aarch64, you can directly download your exploit using `/data/local/tmp/busybox`.
4. If you do not have an arm64 debugging environment locally, you can apply for an arm64 debugging environment on the competition platform.
5. Downloading AOSP requires several tens to hundreds of gigabytes of disk space. You can also browse the AOSP source code online on the following websites.
   1. https://cs.android.com/android
   2. https://android.googlesource.com/?format=HTML
