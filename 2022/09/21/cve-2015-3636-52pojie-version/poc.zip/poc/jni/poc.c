#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/in.h>

int main()
{
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_ICMP);
    struct sockaddr_in sa;
    memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET;
    connect(sock, (const struct sockaddr *) &sa, sizeof(sa));
    
    sa.sin_family = AF_UNSPEC;
    connect(sock, (const struct sockaddr *) &sa, sizeof(sa));
    connect(sock, (const struct sockaddr *) &sa, sizeof(sa));
    
    return 0;

}
