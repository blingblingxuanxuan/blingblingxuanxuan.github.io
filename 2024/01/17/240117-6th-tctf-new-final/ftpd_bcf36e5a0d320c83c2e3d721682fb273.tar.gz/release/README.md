# ftpd
1. save your time on reversing, found source at: https://github.com/o-gs/ftpd 
```diff
@@ -2635,7 +2635,7 @@ ftp_xfer_dir(ftp_session_t   *session,

     /* check if this is a directory */
     session->dp = opendir(session->buffer);
-    if(session->dp == NULL)
+    if(session->dp != NULL)
     {
       /* not a directory; check if it is a file */
       rc = stat(session->buffer, &st);

```
2. the binary is hosting on an arm64 vps, with nx, aslr protection
3. each ftp server will restart automatically every 180s